import logo from '../assets/logo.svg';

const Navigation = ({ account, setAccount }) => {

}

export default Navigation;
